//
//  ExploreView.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

struct ExploreView: View {
    @ObservedObject var viewModel: CoursesViewModel
    @State private var searchText = ""
    @State private var selectedSubject: String = "Industry"
    @State private var selectedCommitment: String = "Hours"
    @State private var selectedAge: String = "Age"

    let subjects = ["Industry", "Coding", "Music", "Web Dev"]
    let commitments = ["Hours", "~10 hrs", "~25 hrs", "~30 hrs"]
    let ages = ["Age", "13-16 yo", "15-16 yo", "15-18 yo"]

    var filteredCourses: [Course] {
        withAnimation {
            viewModel.courses.filter { course in
                let matchesSubject = selectedSubject == "Industry" || course.tags.contains(selectedSubject)
                let matchesCommitment = selectedCommitment == "Hours" || course.hours == selectedCommitment
                let matchesAge = selectedAge == "Age" || course.ageGroup == selectedAge
                let matchesSearch = searchText.isEmpty || 
                    course.title.lowercased().contains(searchText.lowercased()) ||
                    course.provider.lowercased().contains(searchText.lowercased()) ||
                    courseHasMatchingTag(course: course, searchText: searchText)
                
                return matchesSubject && matchesCommitment && matchesAge && matchesSearch
            }
        }
    }
    
    private func courseHasMatchingTag(course: Course, searchText: String) -> Bool {
        for tag in course.tags {
            if tag.lowercased().contains(searchText.lowercased()) {
                return true
            }
        }
        return false
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(UIColor.systemGroupedBackground)
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 20) {
                    Text("Explore")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(.primary)
                    
                    VStack(spacing: 16) {
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)
                            TextField("Search courses...", text: $searchText)
                                .textFieldStyle(PlainTextFieldStyle())
                        }
                        .padding()
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(15)
                        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
                    
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                FilterButton(title: selectedSubject, options: subjects, selection: $selectedSubject)
                                FilterButton(title: selectedCommitment, options: commitments, selection: $selectedCommitment)
                                FilterButton(title: selectedAge, options: ages, selection: $selectedAge)
                            }
                            .padding(.horizontal, 4)
                        }
                    }
                    
                    if filteredCourses.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 50))
                                .foregroundColor(.gray)
                            Text("No courses found")
                                .font(.headline)
                                .foregroundColor(.gray)
                            Text("Try adjusting your filters")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 16) {
                                ForEach(filteredCourses) { course in
                                    NavigationLink(destination: CourseDetailView(course: course)) {
                                        CourseCardView(course: course)
                                    }
                                }
                            }
                            .padding(.top, 8)
                        }
                    }
                }
                .padding()
            }
        }
    }
}

struct FilterButton: View {
    let title: String
    let options: [String]
    @Binding var selection: String
    
    var body: some View {
        Menu {
            ForEach(options, id: \.self) { option in
                Button(action: {
                    selection = option
                }) {
                    HStack {
                        Text(option)
                        if selection == option {
                            Image(systemName: "checkmark")
                        }
                    }
                }
            }
        } label: {
            Text(title)
                .foregroundColor(selection == options[0] ? .gray : .white)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(selection == options[0] ? Color(UIColor.systemBackground) : .blue)
                .cornerRadius(20)
                .shadow(color: Color.black.opacity(0.1), radius: 3, x: 0, y: 2)
        }
    }
}
