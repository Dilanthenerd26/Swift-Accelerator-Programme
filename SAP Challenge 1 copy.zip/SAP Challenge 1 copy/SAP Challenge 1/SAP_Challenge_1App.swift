//
//  SAP_Challenge_1App.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import SwiftUI

@main
struct SAP_Challenge_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
