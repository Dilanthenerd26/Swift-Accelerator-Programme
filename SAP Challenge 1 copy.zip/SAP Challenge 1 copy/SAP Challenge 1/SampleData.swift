//
//  SampleData.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import Foundation

let sampleCourses: [Course] = [
    Course(
        title: "Swift Accelerator",
        provider: "Apple Education",
        tags: ["Coding", "Swift"],
        hours: "~25 hrs",
        ageGroup: "15-16 yo",
        description: "Swift Accelerator is an intensive talent development program for Secondary school students. Over 8 months, students learn to code in Swift using Apple developer technologies, and apply storytelling and design thinking principles to design and build an iOS app.",
        address: "Apple Developer Centre, One-North",
        frequency: "3.5 hours per-week",
        totalHours: "180 hrs",
        category: "Code"
    ),
    Course(
        title: "GarageBand Music Creation",
        provider: "Apple Education",
        tags: ["Music", "Creation"],
        hours: "~10 hrs",
        ageGroup: "13-16 yo",
        description: "Learn to create music using GarageBand on iPad and Mac. Compose, record, and share your own songs.",
        address: "Apple Music Lab",
        frequency: "2 hours per-week",
        totalHours: "40 hrs",
        category: "Music"
    ),
    Course(
        title: "Web Development Bootcamp",
        provider: "Code Academy",
        tags: ["Coding", "Web Dev"],
        hours: "~30 hrs",
        ageGroup: "15-18 yo",
        description: "A hands-on course to learn HTML, CSS, and JavaScript. Build and deploy your own website.",
        address: "Online",
        frequency: "4 hours per-week",
        totalHours: "60 hrs",
        category: "Code"
    ),
    Course(
        title: "Digital Art & Design",
        provider: "Creative Studio",
        tags: ["Industry", "Design"],
        hours: "~25 hrs",
        ageGroup: "13-16 yo",
        description: "Learn digital art fundamentals using industry-standard tools like Adobe Photoshop and Illustrator. Create your own digital artwork portfolio.",
        address: "Creative Hub, Somerset",
        frequency: "2.5 hours per-week",
        totalHours: "50 hrs",
        category: "Design"
    ),
    Course(
        title: "Python for Data Science",
        provider: "Tech Academy",
        tags: ["Coding", "Data Science"],
        hours: "~30 hrs",
        ageGroup: "15-18 yo",
        description: "Introduction to data analysis using Python. Learn pandas, numpy, and data visualization with real-world datasets.",
        address: "Tech Academy Campus",
        frequency: "3 hours per-week",
        totalHours: "75 hrs",
        category: "Code"
    ),
    Course(
        title: "Music Production Basics",
        provider: "Sound Lab",
        tags: ["Music", "Industry"],
        hours: "~25 hrs",
        ageGroup: "15-18 yo",
        description: "Learn the fundamentals of music production, including mixing, mastering, and using professional audio software.",
        address: "Sound Lab Studio",
        frequency: "2.5 hours per-week",
        totalHours: "60 hrs",
        category: "Music"
    ),
    Course(
        title: "Game Development with Unity",
        provider: "Game Dev Academy",
        tags: ["Coding", "Game Dev"],
        hours: "~30 hrs",
        ageGroup: "15-18 yo",
        description: "Create your own 2D and 3D games using Unity game engine. Learn C# programming and game design principles.",
        address: "Online",
        frequency: "3 hours per-week",
        totalHours: "90 hrs",
        category: "Code"
    ),
    Course(
        title: "Digital Marketing Essentials",
        provider: "Marketing Institute",
        tags: ["Industry", "Marketing"],
        hours: "~25 hrs",
        ageGroup: "15-18 yo",
        description: "Learn social media marketing, SEO, content creation, and digital advertising strategies.",
        address: "Business Hub",
        frequency: "2.5 hours per-week",
        totalHours: "50 hrs",
        category: "Business"
    ),
    Course(
        title: "3D Modeling & Animation",
        provider: "Digital Arts School",
        tags: ["Industry", "Design"],
        hours: "~30 hrs",
        ageGroup: "15-18 yo",
        description: "Master 3D modeling and animation using Blender. Create characters, environments, and animated shorts.",
        address: "Digital Arts Campus",
        frequency: "3 hours per-week",
        totalHours: "90 hrs",
        category: "Design"
    ),
    Course(
        title: "Mobile App Design",
        provider: "UX Academy",
        tags: ["Industry", "Design"],
        hours: "~25 hrs",
        ageGroup: "15-16 yo",
        description: "Learn UI/UX design principles for mobile apps. Use Figma and other industry tools to create app prototypes.",
        address: "Design Studio",
        frequency: "2.5 hours per-week",
        totalHours: "60 hrs",
        category: "Design"
    ),
    Course(
        title: "Robotics & Arduino",
        provider: "Tech Labs",
        tags: ["Coding", "Industry"],
        hours: "~30 hrs",
        ageGroup: "13-16 yo",
        description: "Build and program robots using Arduino. Learn electronics, coding, and mechanical engineering basics.",
        address: "Tech Labs Workshop",
        frequency: "3 hours per-week",
        totalHours: "75 hrs",
        category: "Engineering"
    ),
    Course(
        title: "Video Production",
        provider: "Media Academy",
        tags: ["Industry", "Creation"],
        hours: "~25 hrs",
        ageGroup: "15-18 yo",
        description: "Learn video shooting, editing, and post-production using professional tools like Adobe Premiere Pro.",
        address: "Media Studio",
        frequency: "2.5 hours per-week",
        totalHours: "60 hrs",
        category: "Media"
    ),
    Course(
        title: "Cybersecurity Fundamentals",
        provider: "Security Institute",
        tags: ["Coding", "Industry"],
        hours: "~30 hrs",
        ageGroup: "15-18 yo",
        description: "Learn network security, ethical hacking, and cybersecurity best practices. Prepare for basic security certifications.",
        address: "Tech Campus",
        frequency: "3 hours per-week",
        totalHours: "90 hrs",
        category: "Security"
    )
]
