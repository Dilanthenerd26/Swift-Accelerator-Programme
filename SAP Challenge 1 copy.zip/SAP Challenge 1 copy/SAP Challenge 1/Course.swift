//
//  Course.swift
//  SAP Challenge 1
//
//  Created by Veera on 2/6/25.
//

import Foundation

struct Course: Identifiable {
    let id = UUID()
    let title: String
    let provider: String
    let tags: [String]
    let hours: String
    let ageGroup: String
    let description: String
    let address: String
    let frequency: String
    let totalHours: String
    let category: String
}
