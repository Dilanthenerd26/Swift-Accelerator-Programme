//
//  ContentView.swift
//  Personal Dashboard
//
//  Created by Dilan Subhu Veerappan on 23/6/25.
//

import SwiftUI

struct ActivityLog: Identifiable, Codable {
    var id = UUID()
    let date: Date
    let activity: String
    let mood: String
    let hydrationGoal: Int
    let waterDrank: Int
    let name: String
}

struct ContentView: View {
    // MARK: - State Variables
    @State private var mood: String = "😊"
    @State private var hydrationGoal: Int = 8
    @State private var waterDrank: Int = 0
    @State private var themeColor: Color = .blue
    @State private var selectedActivity: String = "Read"
    @State private var name: String = ""
    @State private var showAlert: Bool = false
    @State private var activityLog: [ActivityLog] = []
    @State private var selectedTab: Int = 0
    @State private var showDetail: Bool = false
    @State private var selectedLog: ActivityLog? = nil

    // MARK: - Constants
    let moods = ["😊", "😐", "😢", "😡", "🥳"]
    let activities = ["Read", "Exercise", "Meditate", "Work", "Relax"]

    var body: some View {
        TabView(selection: $selectedTab) {
            // MARK: - Record Tab
            NavigationView {
                Form {
                    WelcomeSection(name: $name, mood: $mood, moods: moods, themeColor: themeColor)
                    HydrationSection(hydrationGoal: $hydrationGoal, waterDrank: $waterDrank, themeColor: themeColor)
                    ActivitySection(selectedActivity: $selectedActivity, activities: activities, showAlert: $showAlert, logActivity: logActivity)
                }
                .navigationTitle("Personal Dashboard")
                .accentColor(themeColor)
            }
            .tabItem {
                Image(systemName: "pencil.and.list.clipboard")
                Text("Record")
            }
            .tag(0)

            // MARK: - My Data Tab
            NavigationView {
                MyDataView(activityLog: activityLog, themeColor: themeColor, onCardTap: handleCardTap)
                    .sheet(isPresented: $showDetail) {
                        if let log = selectedLog {
                            ActivityDetailView(log: log, themeColor: themeColor)
                        }
                    }
            }
            .tabItem {
                Image(systemName: "chart.bar.xaxis")
                Text("My Data")
            }
            .tag(1)

            // MARK: - Settings Tab
            NavigationView {
                SettingsSection(themeColor: $themeColor)
            }
            .tabItem {
                Image(systemName: "gearshape")
                Text("Settings")
            }
            .tag(2)
        }
        .accentColor(themeColor)
    }

    // MARK: - Functions
    private func logActivity() {
        let newLog = ActivityLog(
            date: Date(),
            activity: selectedActivity,
            mood: mood,
            hydrationGoal: hydrationGoal,
            waterDrank: waterDrank,
            name: name
        )
        activityLog.append(newLog)
    }

    private func handleCardTap(log: ActivityLog) {
        selectedLog = log
        showDetail = true
    }
}

// MARK: - MyDataView
struct MyDataView: View {
    let activityLog: [ActivityLog]
    let themeColor: Color
    let onCardTap: (ActivityLog) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Title
            HStack {
                Spacer()
                Text("Activity Log")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(themeColor)
                    .padding(.top)
                Spacer()
            }
            
            // Time of Day Bar
            TimeOfDayBar(themeColor: themeColor)
                .padding(.vertical, 8)
            
            // Content
            if activityLog.isEmpty {
                showEmptyState
            } else {
                showActivityList
            }
        }
        .background(
            LinearGradient(
                gradient: Gradient(colors: [themeColor.opacity(0.2), .white]),
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }

    // MARK: - Computed Properties
    private var showEmptyState: some View {
        VStack {
            Spacer()
            VStack {
                Image(systemName: "tray")
                    .font(.system(size: 48))
                    .foregroundColor(themeColor.opacity(0.4))
                Text("No activities logged yet.")
                    .foregroundColor(.secondary)
                    .padding(.top, 8)
            }
            .frame(maxWidth: .infinity)
            Spacer()
        }
    }

    private var showActivityList: some View {
        ScrollView {
            VStack(spacing: 16) {
                ForEach(sortedLogs) { log in
                    ActivityCard(log: log, themeColor: themeColor, onTap: onCardTap)
                }
            }
            .padding()
        }
    }

    private var sortedLogs: [ActivityLog] {
        activityLog.sorted { $0.date > $1.date }
    }
}

// MARK: - ActivityCard
struct ActivityCard: View {
    let log: ActivityLog
    let themeColor: Color
    let onTap: (ActivityLog) -> Void

    var body: some View {
        Button(action: { onTap(log) }) {
            HStack {
                VStack(alignment: .leading) {
                    Text(log.activity)
                        .font(.headline)
                        .foregroundColor(themeColor)
                    Text(log.date, style: .date)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(timeOfDayString(for: log.date))
                        .font(.caption)
                        .foregroundColor(themeColor.opacity(0.7))
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(themeColor)
            }
            .padding()
            .background(themeColor.opacity(0.1))
            .cornerRadius(14)
            .shadow(color: themeColor.opacity(0.15), radius: 4, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }

    private func timeOfDayString(for date: Date) -> String {
        let hour = Calendar.current.component(.hour, from: date)
        switch hour {
        case 5..<12: return "Morning"
        case 12..<17: return "Afternoon"
        case 17..<21: return "Evening"
        default: return "Night"
        }
    }
}

// MARK: - TimeOfDayBar
struct TimeOfDayBar: View {
    let themeColor: Color
    
    private var currentHour: Int {
        Calendar.current.component(.hour, from: Date())
    }
    
    private let segments = [
        ("Morning", 5..<12),
        ("Afternoon", 12..<17),
        ("Evening", 17..<21),
        ("Night", 21..<24)
    ]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(0..<segments.count, id: \.self) { index in
                let segment = segments[index]
                let isCurrent = segment.1.contains(currentHour) || (index == 3 && currentHour < 5)
                
                VStack {
                    Text(segment.0)
                        .font(.caption)
                        .foregroundColor(isCurrent ? .white : themeColor)
                        .padding(.vertical, 6)
                        .frame(maxWidth: .infinity)
                        .background(isCurrent ? themeColor : themeColor.opacity(0.15))
                        .cornerRadius(8)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .padding(.horizontal)
    }
}

// MARK: - ActivityDetailView
struct ActivityDetailView: View {
    let log: ActivityLog
    let themeColor: Color

    var body: some View {
        VStack(spacing: 24) {
            Text("Activity Details")
                .font(.title)
                .bold()
                .foregroundColor(themeColor)
            
            VStack(alignment: .leading, spacing: 16) {
                DetailRow(icon: "figure.walk", label: "Activity", value: log.activity, themeColor: themeColor)
                DetailRow(icon: "calendar", label: "Date", value: log.date.formatted(date: .abbreviated, time: .omitted), themeColor: themeColor)
                DetailRow(icon: "clock", label: "Time", value: log.date.formatted(date: .omitted, time: .shortened), themeColor: themeColor)
                DetailRow(icon: "person", label: "Name", value: log.name.isEmpty ? "(Not set)" : log.name, themeColor: themeColor)
                DetailRow(icon: "face.smiling", label: "Mood", value: log.mood, themeColor: themeColor)
                DetailRow(icon: "drop.fill", label: "Hydration", value: "\(log.waterDrank)/\(log.hydrationGoal) cups", themeColor: themeColor)
            }
            .font(.title3)
            .padding()
            .background(themeColor.opacity(0.1))
            .cornerRadius(14)
            
            Spacer()
        }
        .padding()
    }
}

// MARK: - DetailRow
struct DetailRow: View {
    let icon: String
    let label: String
    let value: String
    let themeColor: Color

    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(themeColor)
            Text("\(label): ")
                .bold()
            Text(value)
        }
    }
}

// MARK: - SettingsSection
struct SettingsSection: View {
    @Binding var themeColor: Color

    var body: some View {
        Form {
            Section(header: Text("Appearance").foregroundColor(themeColor)) {
                ColorPicker("Theme Color", selection: $themeColor)
                    .padding(10)
                    .background(themeColor.opacity(0.1))
                    .cornerRadius(10)
            }
        }
        .navigationTitle("Settings")
    }
}

#Preview {
    ContentView()
}
