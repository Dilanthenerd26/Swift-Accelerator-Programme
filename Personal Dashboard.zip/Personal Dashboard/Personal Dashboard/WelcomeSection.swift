//
//  WelcomeSection.swift
//  Personal Dashboard
//
//  Created by Dilan Subhu Veerappan on 23/6/25.
//


import SwiftUI

struct WelcomeSection: View {
    @Binding var name: String
    @Binding var mood: String
    let moods: [String]
    var themeColor: Color = .blue

    var body: some View {
        Section(header: Text("Welcome").foregroundColor(themeColor)) {
            VStack(alignment: .leading, spacing: 12) {
                TextField("Enter your name", text: $name)
                    .padding(10)
                    .background(themeColor.opacity(0.1))
                    .cornerRadius(10)
                Picker("Mood", selection: $mood) {
                    ForEach(moods, id: \.self) { mood in
                        Text(mood)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .background(themeColor.opacity(0.1))
                .cornerRadius(10)
            }
            .padding(6)
        }
    }
}