//
//  HydrationSection.swift
//  Personal Dashboard
//
//  Created by Dilan Subhu Veerappan on 23/6/25.
//


import SwiftUI

struct HydrationSection: View {
    @Binding var hydrationGoal: Int
    @Binding var waterDrank: Int
    var themeColor: Color = .blue

    var body: some View {
        Section(header: Text("Hydration").foregroundColor(themeColor)) {
            VStack(alignment: .leading, spacing: 12) {
                Stepper("Goal: \(hydrationGoal) cups", value: $hydrationGoal, in: 1...20)
                    .padding(10)
                    .background(themeColor.opacity(0.1))
                    .cornerRadius(10)
                Stepper("Drank: \(waterDrank) cups", value: $waterDrank, in: 0...hydrationGoal)
                    .padding(10)
                    .background(themeColor.opacity(0.1))
                    .cornerRadius(10)
                ProgressView(value: Double(waterDrank), total: Double(hydrationGoal))
                    .accentColor(themeColor)
                    .padding(.vertical, 8)
            }
            .padding(6)
        }
    }
}