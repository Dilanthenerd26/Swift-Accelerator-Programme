//
//  ActivitySection.swift
//  Personal Dashboard
//
//  Created by Dilan Subhu Veerappan on 23/6/25.
//


import SwiftUI

struct ActivitySection: View {
    @Binding var selectedActivity: String
    let activities: [String]
    @Binding var showAlert: Bool
    let logActivity: () -> Void

    var body: some View {
        Section(header: Text("Activity")) {
            Picker("Today's Activity", selection: $selectedActivity) {
                ForEach(activities, id: \.self) { activity in
                    Text(activity)
                }
            }
            Button("Log Activity") {
                logActivity()
                showAlert = true
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Activity Logged"),
                    message: Text("You chose to \(selectedActivity.lowercased()) today!"),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
}