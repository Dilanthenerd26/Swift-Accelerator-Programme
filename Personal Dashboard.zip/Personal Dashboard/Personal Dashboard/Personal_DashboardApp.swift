//
//  Personal_DashboardApp.swift
//  Personal Dashboard
//
//  Created by Dilan Subhu Veerappan on 23/6/25.
//

import SwiftUI

@main
struct Personal_DashboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
